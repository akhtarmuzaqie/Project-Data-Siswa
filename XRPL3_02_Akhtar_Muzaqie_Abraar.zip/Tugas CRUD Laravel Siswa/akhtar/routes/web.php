<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/
Route::get('/','Homecontroller@Index');
Route::get('home','pagescontroller@homepage');
Route::get('about','pagescontroller@about');
Route::get('siswa','siswacontroller@siswa');
Route::get('register','pagescontroller@register');



// Siswa
Route::get('siswa/create','siswacontroller@create');
Route::post('siswa', 'siswacontroller@store');
Route::get('siswa/{siswa}','siswacontroller@show');
Route::get('siswa/{siswa}/edit','siswacontroller@edit');
Route::post('siswa/{siswa}/update','siswacontroller@update');
Route::get('siswa/{siswa}/delete','siswacontroller@delete');
Route::get('siswa/cetak','siswacontroller@cetak');

//guru
Route::get('guru','gurucontroller@guru');
Route::get('guru/create','gurucontroller@create');
Route::post('guru', 'gurucontroller@store');
Route::get('guru/{guru}','gurucontroller@show');
Route::get('guru/{guru}/edit','gurucontroller@edit');
Route::post('guru/{guru}/update','gurucontroller@update');
Route::get('guru/{guru}/delete','gurucontroller@delete');

//kelas
Route::get('kelas','kelascontroller@kelas');
Route::get('kelas/create','kelascontroller@create');
Route::post('kelas', 'kelascontroller@store');
Route::get('kelas/{kelas}','kelascontroller@show');
Route::get('kelas/{kelas}/edit','kelascontroller@edit');
Route::post('kelas/{kelas}/update','kelascontroller@update');
Route::get('kelas/{kelas}/delete','kelascontroller@delete');

//walikelas
Route::get('wali','walikelascontroller@wali');
Route::get('wali/create','walikelascontroller@create');
Route::post('wali', 'walikelascontroller@store');
Route::get('wali/{wali}/edit','walikelascontroller@edit');
Route::post('wali/{wali}/update','walikelascontroller@update');
Route::get('wali/{wali}/delete','walikelascontroller@delete');







Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');





