<?php $__env->startSection('main'); ?>
<div id="wali" class="masthead bg-primary text-center text-light mb-0"> 
<h2>Tambah Siswa</h2>
<center>
<div class="divider-custom divider-light">
    <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
    <div class="divider-custom-line"></div>
</div>
<form action="<?php echo e(url('wali')); ?>" method="post" class="lead" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>

<div class="form-group">

<label for="id_kelas" class="control-label text-secondary">Nama Kelas :</label>


<select class="form-control col-md-4 col-form-label text-center" type="text"  name="id_kelas">
            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($kelas->id_kelas); ?>">><?php echo e($kelas->nama_kelas); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>


</div>

<div class="form-group">

<label for="nip" class="control-label text-secondary">Nama Guru :</label>

<select class="form-control col-md-4 col-form-label text-center" type="text"  name="nip">
            <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($guru->nip); ?>">><?php echo e($guru->nama_guru); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>



</div>
<br>
<button type="submit" class="btn btn-outline-light btn-lg">Submit</button>
<a href="<?php echo e('wali'); ?>" class="btn btn-outline-light btn-lg">Cancel</a>
</form>

</center>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>