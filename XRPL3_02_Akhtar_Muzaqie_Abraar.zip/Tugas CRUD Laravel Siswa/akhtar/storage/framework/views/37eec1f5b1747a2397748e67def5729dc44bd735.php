<?php $__env->startSection('main'); ?>
<div id="kelas" class="masthead bg-primary text-center text-light mb-0"> 
<h2>Tambah Kelas</h2>
<center>
<div class="divider-custom divider-light">
    <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
    <div class="divider-custom-line"></div>
</div>
<form action="<?php echo e(url('kelas')); ?>" method="post" class="lead">
<?php echo e(csrf_field()); ?>

<div class="form-group">
<label for="id_kelas" class="control-label text-secondary">ID Kelas    :  </label> <input name="id_kelas" type="text" class="form-control col-md-4 col-form-label text-md-center">



</div>
<div class="form-group">

<label for="nama_kelas" class="control-label text-secondary">Nama Kelas :  </label> <input name="nama_kelas" type="text" class="form-control col-md-4 col-form-label text-md-center">



</div>

<br>
<button type="submit" class="btn btn-outline-light btn-lg">Submit</button>
<a href="http://localhost/laravel/public/kelas" class="btn btn-outline-light btn-lg">Cancel</a>
</form>

</center>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>