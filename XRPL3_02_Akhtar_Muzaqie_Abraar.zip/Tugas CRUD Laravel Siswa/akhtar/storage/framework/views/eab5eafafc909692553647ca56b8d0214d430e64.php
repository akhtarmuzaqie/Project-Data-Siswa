<?php $__env->startSection('main'); ?>
  <div id="kelas" class="masthead bg-primary">
    <h2>Detail Kelas</h2>

    <table class="lead table table-striped">
    <tbody>
      <tr>
        <th>ID Kelas</th>
        <td><?php echo e($kelas->id_kelas); ?></td>
      </tr>
      <tr>
        <th>Nama Kelas</th>
        <td><?php echo e($kelas->nama_kelas); ?></td>
      </tr>
      <tr>
        <th>Anggota Siswa</th>
        <td>
        <?php $__currentLoopData = $kelas->siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
          <p>> <?php echo e(!empty($list->nama_siswa) ?
                        $list->nama_siswa : '-'); ?><br>
                        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        </tr>
        </tbody>
        <tr>
    </table>
    <center>
    <a href="http://localhost/laravel/public/kelas" class=" btn btn-outline-light btn-xl"><- Go Back</a>
    </center>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>