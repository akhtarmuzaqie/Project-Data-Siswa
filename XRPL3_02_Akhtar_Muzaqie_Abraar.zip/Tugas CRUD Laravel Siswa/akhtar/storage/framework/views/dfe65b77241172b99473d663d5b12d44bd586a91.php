<?php $__env->startSection('main'); ?>
<div id="walikelas">
    <h2>Wali Kelas</h2>

    <?php if(!empty($wali_list)): ?>
    <table class="table">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Guru</th>
                <th>Nama Kelas</th>
                
                <th>aksi</th>
            </tr>
        </thead>
        <tbod
        >
            <?php $__currentLoopData = $wali_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $walikelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($walikelas->id_walikelas); ?></td>
                <td><?php echo e($walikelas->guru->nama_guru); ?></td>
                <td><?php echo e($walikelas->kelas->nama_kelas); ?></td>
                
                <td>
            <a class="btn btn-success btn-sm" href="<?php echo e(url('walikelas/' .$walikelas->nip)); ?>">Detail</a>
            <a href="<?php echo e(url('walikelas/'.$walikelas->nip.'/edit')); ?>" class="btn btn-warning btn-sm">Edit</a>
            <a href="<?php echo e(url('walikelas/'.$walikelas->nip.'/delete')); ?>" class="btn btn-danger btn-sm">Delete</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
    <?php else: ?>
    <p>Data guru tidak muncul</p>
    <?php endif; ?>

    <a href="<?php echo e(url('create')); ?>" class="btn btn-primary">Tambah Pengajar</a>
    <br>
    <br>
    <br>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>