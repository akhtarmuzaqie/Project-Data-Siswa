<?php $__env->startSection('main'); ?>
    <!-- Main Section -->
    <section class="main-section">
        <!-- Add Your Content Inside -->
        <div class="content">
            <!-- Remove This Before You Start -->
            <h1>Selamat Datang <?php echo e(Session::get('name')); ?>. Apa Kabar?</h1>
            <p>Jadwal hari ini adalah sekolah</p>

            <h2>* Email kamu : <?php echo e(Session::get('email')); ?></h2>
            <h2>* Status Login : <?php echo e(Session::get('login')); ?></h2>
            <a href="/logout" class="btn btn-primary btn-lg">Logout</a>

        </div>
        <!-- /.content -->
    </section>
    <!-- /.main-section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>