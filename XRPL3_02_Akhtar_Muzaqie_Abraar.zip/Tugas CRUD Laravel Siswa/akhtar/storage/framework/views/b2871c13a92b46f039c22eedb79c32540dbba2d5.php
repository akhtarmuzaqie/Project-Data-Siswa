<?php $__env->startSection('main'); ?>
<div id="guru">
    <h2>Siswa</h2>

    <?php if(!empty($guru_list)): ?>
    <table class="table">
        <thead>
            <tr>
                <th>NIP</th>
                <th>Nama </th>
                <th>Tgl Lahir</th>
                <th>Jenis Kelamin</th>
                <th>aksi</th>
            </tr>
        </thead>
        <tbod
        >
            <?php $__currentLoopData = $guru_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($guru->nip); ?></td>
                <td><?php echo e($guru->nama_guru); ?></td>
                <td><?php echo e($guru->tanggal_lahir); ?></td>
                <td><?php echo e($guru->jenis_kelamin); ?></td>
                <td>
            <a class="btn btn-success btn-sm" href="<?php echo e(url('guru/' .$guru->nip)); ?>">Detail</a>
            <a href="<?php echo e(url('guru/'.$guru->nip.'/edit')); ?>" class="btn btn-warning btn-sm">Edit</a>
            <a href="<?php echo e(url('guru/'.$guru->nip.'/delete')); ?>" class="btn btn-danger btn-sm">Delete</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
    <?php else: ?>
    <p>Data guru tidak muncul</p>
    <?php endif; ?>

    <a href="<?php echo e(url('create')); ?>" class="btn btn-primary">Tambah Pengajar</a>
    <br>
    <br>
    <br>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>