@sections('content')
<section class="main-section">
	<div class="content">
		<h1>Home Belajar Laravel</h1>
		<p>Apa Saja yang sudah amu pelajari?</p>

		<h2>Templating Laravel</h2>







<?php $__env->stopSection(); ?>
	</div>
</section>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>