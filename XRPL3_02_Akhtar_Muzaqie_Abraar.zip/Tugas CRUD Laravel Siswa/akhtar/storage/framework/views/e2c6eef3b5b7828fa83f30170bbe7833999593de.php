<?php $__env->startSection('main'); ?>
<div id="siswa">
    <h2>Siswa</h2>

    <?php 
    if(!empty($siswa)):
    ?>
    <ul>
    <?php
     foreach ($siswa as $anak): 
    ?>
    <li><?= $anak ?></li>
    <?php endforeach ?>
    </ul>

     <?php else: ?>
     <p>Tidak ada data siswa.</p>
     <?php endif ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<div id="footer">
    <p>&copy; 2019 Belajar_laravel</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>