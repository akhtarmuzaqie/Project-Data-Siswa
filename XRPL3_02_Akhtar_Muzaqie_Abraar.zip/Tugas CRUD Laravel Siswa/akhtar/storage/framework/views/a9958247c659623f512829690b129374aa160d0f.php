<?php $__env->startSection('main'); ?>
<div id="hompage">
	<h2>Homepage</h2>
	<p>Selamat belajar Laravel</p>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<div id="footer">
	<p>&copy; 2019 Belajar_laravel</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>