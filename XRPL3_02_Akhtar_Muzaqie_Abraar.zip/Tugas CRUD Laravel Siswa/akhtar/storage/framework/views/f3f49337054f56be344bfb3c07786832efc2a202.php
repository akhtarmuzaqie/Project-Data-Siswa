<?php $__env->startSection('main'); ?>
<div id="siswa" class="masthead bg-primary text-center text-light mb-0"> 
<h2>Edit Siswa</h2>
<center>
<div class="divider-custom divider-light">
    <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
    <div class="divider-custom-line"></div>
</div>
<form action="<?php echo e(url('siswa/' . $siswa->id . '/update')); ?>" method="post" class="lead" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>

<div class="form-group">

<label for="nisn" class="control-label text-secondary">NISN    :   </label><input name="nisn" type="text" class="form-control col-md-4 col-form-label text-md-center"value="<?php echo e($siswa->nisn); ?>" readonly>


</div>
<div class="form-group">
<label for="id_kelas" class="control-label text-secondary">ID Kelas    :  </label> 
<?php if(!empty($kelas)): ?>
<select class="form-control col-md-4 col-form-label text-center " name="id_kelas">
  <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($k->id_kelas); ?>"><?php echo e($k->nama_kelas); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php else: ?>
<p>Tidak ada data kelas.</p>
<?php endif; ?>
</div>


<div class="form-group">

<label for="nama_siswa" class="control-label text-secondary">Nama  :  </label> <input name="nama_siswa" type="text" class="form-control col-md-4 col-form-label text-md-center" value="<?php echo e($siswa->nama_siswa); ?>">



</div>
<div class="form-group">

<label for="tanggal_lahir" class="control-label text-secondary">Tanggal Lahir  : </label><input name="tanggal_lahir" type="date"class="form-control col-md-4 col-form-label text-md-center" value="<?php echo e($siswa->tanggal_lahir); ?>">


</div>
<div class="form-group">

<label for="jenis_kelamin" class="control-label text-secondary">Jenis Kelamin : </label>
<br>
<?php if($siswa->jenis_kelamin=="P"): ?>

<select class="form-control col-md-4 col-form-label text-md-center" type="text" name="jenis_kelamin">
    <option value="P">Perempuan</option>
    <option value="L">Laki-Laki</option>
    

    
</select>




<?php elseif($siswa->jenis_kelamin=="L"): ?>

<select class="form-control col-md-4 col-form-label text-md-center" type="text" name="jenis_kelamin">
    <option value="L">Laki-Laki</option>
    <option value="P">Perempuan</option>

    
</select>



<?php endif; ?>
</div>
<div class="form-group">

<label for="image" class="control-label text-secondary">pilih Gambar  :</label> 
<input name="image" type="file" class="form-control col-md-4 col-form-label text-md-center">
  

</div>
<br>  
<button type="submit" class="btn btn-outline-light btn-xl">Submit</button>
<a href="http://localhost/laravel/public/siswa" class="btn btn-outline-light btn-xl">Cancel</a>
</form>

</center>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>