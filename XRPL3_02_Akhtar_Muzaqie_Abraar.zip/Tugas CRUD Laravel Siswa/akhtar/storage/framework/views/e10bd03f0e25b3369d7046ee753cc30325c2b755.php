<?php $__env->startSection('main'); ?>
<div id="siswa" class="masthead bg-primary text-center text-light mb-0"> 
<h2>Edit Walikelas</h2>
<center>
<div class="divider-custom divider-light">
    <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
    <div class="divider-custom-line"></div>
</div>
<form action="<?php echo e(url('wali/' . $wali->id.'/update')); ?>" method="post" class="lead" enctype="multipart/form-data">
	<?php echo e(csrf_field()); ?>


	<div class="form-group">
		<label for="id_kelas" class="control-label text-secondary">Nama Kelas   :</label>
		<select required class="form-control col-form-label text-center" type="text" name="id_kelas">
			<?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($k->id_kelas); ?>">><?php echo e($k->nama_kelas); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
	</div>
	<div class="form-group">
		<label for="nip" class="control-label text-secondary">Nama Guru   :</label>
		<select required class="form-control col-form-label text-center" type="text" name="nip">
			<?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($g->nip); ?>">><?php echo e($g->nama_guru); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
	</div>
	<br>
	<button type="submit" class="btn btn-outline-light btn-x1">->Submit</button>
	<a href="wali" class="btn btn-outline-light btn-x1">cancel</a>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>