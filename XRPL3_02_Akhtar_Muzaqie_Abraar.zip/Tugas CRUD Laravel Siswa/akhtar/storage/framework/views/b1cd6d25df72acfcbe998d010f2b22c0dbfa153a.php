<?php $__env->startSection('main'); ?>
 <div id="siswa" class="masthead bg-primary">
    <h2 class="text-center">Detail Guru</h2>

    <tr>
    	<center>
    		<div class="profile-main">
    			<img src="<?php echo e(asset('img/'.$guru->image)); ?>" class="rounded-circle" alt="image" style="width: 10%;">
    			<h3 class="name"><?php echo e($guru->nama_guru); ?></h3>

    		</div>
    	</center>
    </tr>

    <table class="lead table table-striped">
      <tbody>
      <tr>
        <th>NIP</th>
        <td><?php echo e($guru->nip); ?></td>
      </tr>
      <tr>
        <th>Nama</th>
        <td><?php echo e($guru->nama_guru); ?></td>
      </tr>
      <tr>
        <th>Tanggal Lahir</th>
        <td><?php echo e($guru->tanggal_lahir); ?></td>
      </tr>
      <tr>
        <th>Jenis Kelamin</th>
        <td><?php echo e($guru->jenis_kelamin); ?></td>
      </tr>
      </tbody>
      <tr>
      </tbody>
      <tr>
    </table>
    <center>
    <a href="<?php echo e(url('guru')); ?>" class=" btn btn-outline-light btn-xl"><- Go Back</a>
    </center>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>