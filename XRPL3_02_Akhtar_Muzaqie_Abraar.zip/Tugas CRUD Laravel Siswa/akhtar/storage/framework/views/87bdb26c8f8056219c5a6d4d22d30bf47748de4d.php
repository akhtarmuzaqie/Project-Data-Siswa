<?php $__env->startSection('main'); ?>
<h1>Masukkan data Diri dibawah</h1>
<div class="container" id="form">
<table>
	<form>
		<tr>
			<td><label>Nama Lengkap</label></td>
			<td><input type="text" name="namalengkap" placeholder="Isi Disini.." required_once></td>
		</tr>

		<tr>
			<td><label>NIS</label></td>
			<td><input type="text" name="namalengkap" placeholder="Isi Disini.." required_once></td>
		</tr>
		<tr>
			<td><label>Kelas</label></td>
			<td><input type="text" name="namalengkap" placeholder="Isi Disini.." required_once></td>
		</tr>
		<tr>
			<td><label>Jurusan</label></td>
			<td><input type="text" name="namalengkap" placeholder="Isi Disini.." required_once></td>
		</tr>
		<tr>
			<td><label>Alamat</label></td>
			<td><input type="text" name="namalengkap" placeholder="Isi Disini.." required_once></td>
		</tr>

		<tr><td><input type="submit" value="Submit"></td></tr>
		
	</form>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>