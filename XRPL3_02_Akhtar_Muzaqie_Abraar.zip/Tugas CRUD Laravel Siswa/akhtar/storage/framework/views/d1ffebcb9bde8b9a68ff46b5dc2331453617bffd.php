<?php $__env->startSection('main'); ?>
<section class="masthead text-light bg-primary text-center" id="kelas">
    
        <h2>Daftar Kelas</h2>
        <div class="divider-custom divider-light">
        <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
        <div class="divider-custom-line"></div>
      </div>    
        <?php if(!empty($kelas_list)): ?>
        
          <table class="table lead text-center text-secondary ">
          <thead>
            <tr>
              <th>ID Kelas</th>
              <th>Nama Kelas</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>

          <?php  $i=0 ?>
            <?php $__currentLoopData = $kelas_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
              <tr>
              
                <td><?php echo e($kelas->id_kelas); ?></td>
                <td><?php echo e($kelas->nama_kelas); ?></td>
                <td><a class="btn btn-success btn-sm" href="<?php echo e(url('kelas/' . $kelas->id)); ?>">Detail</a>
                <a class="btn btn-warning btn-sm" href="<?php echo e(url('kelas/' . $kelas->id.'/edit')); ?>">Edit</a>
                <a class="btn btn-danger btn-sm" href="<?php echo e(url('kelas/' . $kelas->id.'/delete')); ?>" onclick="confirm('Are you sure you want to delete this?')">Delete</a></td>
                <?php $i++ ?>
              </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tr>
          </table>
          <h4 class="text-center text-secondary"><?php echo "Jumlah Total Kelas: $i"; ?></h4>
        <?php else: ?>   
            <p>Tidak ada data kelas</p>
        <?php endif; ?>
        
        <br>
        <a href="<?php echo e(url('kelas/create')); ?>" class="btn btn-outline-light btn-xl"> + Tambah Kelas</a>
    
</section>
  
<?php $__env->stopSection(); ?> 



<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>