<?php $__env->startSection('main'); ?>
 <div id="siswa" class="masthead bg-primary">
    <h2 class="text-center">Detail Siswa</h2>

    <tr>
    	<center>
    		<div class="profile-main">
    			<img src="<?php echo e(asset('img/'.$siswa->image)); ?>" class="rounded-circle" alt="image" style="width: 10%;">
    			<h3 class="name"><?php echo e($siswa->nama_siswa); ?></h3>

    		</div>
    	</center>
    </tr>

    <table class="lead table table-striped">
      <tbody>
      <tr>
        <th>NISN</th>
        <td><?php echo e($siswa->nisn); ?></td>
      </tr>
      <tr>
        <th>Nama Kelas</th>
        <td><?php echo e(!empty($siswa->kelas->nama_kelas) ?
                        $siswa->kelas->nama_kelas : '-'); ?></td>
      </tr>
      <tr>
        <th>Nama</th>
        <td><?php echo e($siswa->nama_siswa); ?></td>
      </tr>
      <tr>
        <th>Tanggal Lahir</th>
        <td><?php echo e($siswa->tanggal_lahir); ?></td>
      </tr>
      <tr>
        <th>Jenis Kelamin</th>
        <td><?php echo e($siswa->jenis_kelamin); ?></td>
      </tr>
      </tbody>
      <tr>
    </table>
    <center>
    <a href="<?php echo e(url('siswa')); ?>" class=" btn btn-outline-light btn-xl"><- Go Back</a>
    </center>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>