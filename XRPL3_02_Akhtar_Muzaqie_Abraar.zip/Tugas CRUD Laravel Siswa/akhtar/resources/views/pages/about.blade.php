@extends('template')

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


@section('main')
<div id="about">
	<h2>About</h2>
	<p>Selamat belajar Laravel <br>
	Sistem ini digunakan sebagai latihan</p>
</div>
@stop

@section('footer')

@stop