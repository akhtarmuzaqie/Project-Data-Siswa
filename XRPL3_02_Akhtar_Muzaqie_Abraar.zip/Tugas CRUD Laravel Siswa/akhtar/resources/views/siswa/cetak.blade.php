@extends('temppdf')

@section('main')
<section class="masthead text-light bg-primary text-center" id="siswa">
    
    <title>Laporan Daftar Siswa</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head>
<body>
    <style type="text/css">
        table tr td,
        table tr th{
            font-size: 9pt;
        }
        </style>
        <center>
        <h5>Laporan Daftar Siswa</h5>
        </center>
            
            <table class="table table-bordered">
          <thead>
            <tr>
              <th>No</th>
              <th>NISN</th>
              <th>Nama</th>
              <th>Nama Kelas</th>
              <th>Tgl Lahir</th>
              <th>Jenis Kelamin</th>
              
            </tr>
          </thead>
          <tbody>

            @php  $i=1 @endphp
            @foreach($siswa as $siswa)
              
              <tr>
                <td>{{ $i++ }}</td>
                <td>{{ $siswa->nisn}}</td>
                <td>{{ $siswa->nama_siswa }}</td>
                <td>{{ !empty($siswa->kelas->nama_kelas)?
                      $siswa->kelas->nama_kelas : '-' }}</td>
                <td>{{ $siswa->jenis_kelamin }}</td>
                <td>{{ $siswa->tanggal_lahir }}</td>
              
                </tr>
            
            @endforeach
          </tbody>
                  <tfoot></tfoot>
          </table>
</div>
@endsection