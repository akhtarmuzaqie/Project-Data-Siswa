@extends('template')
@section('main')
<div id="siswa" class="masthead bg-primary text-center text-light mb-0"> 
<h2>Tambah Siswa</h2>
<center>
<div class="divider-custom divider-light">
    <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
    <div class="divider-custom-line"></div>
</div>
<form action="{{ url('siswa') }}" method="post" class="lead" enctype="multipart/form-data">
{{ csrf_field()}}
<div class="form-group">

<label for="nisn" class="control-label text-secondary">NISN    : </label>  <input name="nisn" type="text" class="form-control col-md-4 col-form-label text-md-center">



</div>
<div class="form-group">

<label for="id" class="control-label text-secondary">Nama Kelas :</label>
        <select  required class="form-control col-md-4 col-form-label text-center" type="text"  name="id_kelas">
            @foreach ($kelas as $k)
            <option value="{{$k->id_kelas}}">{{$k->nama_kelas}}</option>
            @endforeach
        </select>
</div>
<div class="form-group">

<label for="nama_siswa" class="control-label text-secondary">Nama  :   </label><input name="nama_siswa" type="text" class="form-control col-md-4 col-form-label text-md-center">



</div>
<div class="form-group">

<label for="tanggal_lahir" class="control-label text-secondary">Tanggal Lahir  :</label> <input name="tanggal_lahir" type="date"class="form-control col-md-4 col-form-label text-md-center">


</div>
<div class="form-group">

<label for="jenis_kelamin" class="control-label text-secondary">Jenis Kelamin :</label>


<select class="form-control col-md-4 col-form-label text-md-center" type="text" name="jenis_kelamin">
    <option value=""> </option>
    <option value="L">Laki-Laki</option>
    <option value="P">Perempuan</option>

    
</select>



</div>
<div class="form-group">

<label for="image" class="control-label text-secondary">pilih Gambar  :</label> 
<input name="image" type="file" class="form-control col-md-4 col-form-label text-md-center">
  

</div>
<br>
<button type="submit" class="btn btn-outline-light btn-lg">Submit</button>
<a href="{{url('siswa')}}" class="btn btn-outline-light btn-lg">Cancel</a>
</form>

</center>
</div>
@stop