@extends('template')

@section('main')
<section class="masthead text-light bg-primary text-center" id="guru">
    
        <h2>Daftar Siswa</h2>
        <div class="divider-custom divider-light">
        <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
        <div class="divider-custom-line"></div>
      </div>    
        @if (!empty($siswa_list))
        
          <table class="table lead text-center text-secondary ">
          <thead>
            <tr>
              <th>NISN</th>
              <th>Nama</th>
              <th>Jenis Kelamin</th>
              <th>Tgl Lahir</th>
              <th>Kelas</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>

          <?php  $i=0 ?>
            @foreach($siswa_list as $siswa)
              
              <tr>
              
                <td>{{ $siswa->nisn }}</td>
                <td>{{ $siswa->nama_siswa }}</td>
                <td>{{ $siswa->jenis_kelamin }}</td>
                <td>{{ $siswa->tanggal_lahir }}</td>
                <td>{{ !empty($siswa->kelas->nama_kelas) ? $siswa->kelas->nama_kelas : '-'}}
                </td>
                <td><a class="btn btn-success btn-sm" href="{{ url('siswa/' . $siswa->id) }}">Detail</a>
                <a class="btn btn-warning btn-sm" href="{{ url('siswa/' . $siswa->id.'/edit') }}">Edit</a>
                <a class="btn btn-danger btn-sm" href="{{ url('siswa/' . $siswa->id.'/delete') }}" onclick="confirm('Are you sure you want to delete this?')">Delete</a></td>
                <?php $i++ ?>
              </tr>
            
           @endforeach
          </tbody>
          <tr>
          </table>
          <h4 class="text-center text-secondary"><?php echo "Jumlah Total siswa: $i"; ?></h4>
        @else   
            <p>Tidak ada data Siswa</p>
        @endif
        
        <br>
        <a href="{{ url('siswa/create') }}" class="btn btn-outline-light btn-xl"> + Tambah siswa</a>
        <a href="{{ url('siswa/cetak') }}" class="btn btn-outline-light btn-xl"> Cetak PDF</a>
</section>
  
@stop 

