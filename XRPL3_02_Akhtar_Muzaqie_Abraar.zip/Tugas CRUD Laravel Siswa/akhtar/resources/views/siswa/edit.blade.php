@extends('template')
@section('main')
<div id="siswa" class="masthead bg-primary text-center text-light mb-0"> 
<h2>Edit Siswa</h2>
<center>
<div class="divider-custom divider-light">
    <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
    <div class="divider-custom-line"></div>
</div>
<form action="{{ url('siswa/' . $siswa->id . '/update') }}" method="post" class="lead" enctype="multipart/form-data">
{{ csrf_field() }}
<div class="form-group">

<label for="nisn" class="control-label text-secondary">NISN    :   </label><input name="nisn" type="text" class="form-control col-md-4 col-form-label text-md-center"value="{{$siswa->nisn}}" readonly>


</div>
<div class="form-group">
<label for="id_kelas" class="control-label text-secondary">ID Kelas    :  </label> 
@if(!empty($kelas))
<select class="form-control col-md-4 col-form-label text-center " name="id_kelas">
  @foreach ($kelas as $k)
  <option value="{{$k->id_kelas}}">{{$k->nama_kelas}}</option>
  @endforeach
</select>
@else
<p>Tidak ada data kelas.</p>
@endif
</div>


<div class="form-group">

<label for="nama_siswa" class="control-label text-secondary">Nama  :  </label> <input name="nama_siswa" type="text" class="form-control col-md-4 col-form-label text-md-center" value="{{$siswa->nama_siswa}}">



</div>
<div class="form-group">

<label for="tanggal_lahir" class="control-label text-secondary">Tanggal Lahir  : </label><input name="tanggal_lahir" type="date"class="form-control col-md-4 col-form-label text-md-center" value="{{$siswa->tanggal_lahir}}">


</div>
<div class="form-group">

<label for="jenis_kelamin" class="control-label text-secondary">Jenis Kelamin : </label>
<br>
@if ($siswa->jenis_kelamin=="P")

<select class="form-control col-md-4 col-form-label text-md-center" type="text" name="jenis_kelamin">
    <option value="P">Perempuan</option>
    <option value="L">Laki-Laki</option>
    

    
</select>




@elseif ($siswa->jenis_kelamin=="L")

<select class="form-control col-md-4 col-form-label text-md-center" type="text" name="jenis_kelamin">
    <option value="L">Laki-Laki</option>
    <option value="P">Perempuan</option>

    
</select>



@endif
</div>
<div class="form-group">

<label for="image" class="control-label text-secondary">pilih Gambar  :</label> 
<input name="image" type="file" class="form-control col-md-4 col-form-label text-md-center">
  

</div>
<br>  
<button type="submit" class="btn btn-outline-light btn-xl">Submit</button>
<a href="http://localhost/laravel/public/siswa" class="btn btn-outline-light btn-xl">Cancel</a>
</form>

</center>
</div>
@stop