@extends('template')

@section('main')
 <div id="siswa" class="masthead bg-primary">
    <h2 class="text-center">Detail Siswa</h2>

    <tr>
    	<center>
    		<div class="profile-main">
    			<img src="{{asset('img/'.$siswa->image)}}" class="rounded-circle" alt="image" style="width: 10%;">
    			<h3 class="name">{{$siswa->nama_siswa}}</h3>

    		</div>
    	</center>
    </tr>

    <table class="lead table table-striped">
      <tbody>
      <tr>
        <th>NISN</th>
        <td>{{ $siswa->nisn }}</td>
      </tr>
      <tr>
        <th>Nama Kelas</th>
        <td>{{ !empty($siswa->kelas->nama_kelas) ?
                        $siswa->kelas->nama_kelas : '-' }}</td>
      </tr>
      <tr>
        <th>Nama</th>
        <td>{{ $siswa->nama_siswa }}</td>
      </tr>
      <tr>
        <th>Tanggal Lahir</th>
        <td>{{ $siswa->tanggal_lahir }}</td>
      </tr>
      <tr>
        <th>Jenis Kelamin</th>
        <td>{{ $siswa->jenis_kelamin }}</td>
      </tr>
      </tbody>
      <tr>
    </table>
    <center>
    <a href="{{ url('siswa')}}" class=" btn btn-outline-light btn-xl"><- Go Back</a>
    </center>
  </div>
@stop