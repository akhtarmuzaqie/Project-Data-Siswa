@extends('template')
@section('main')
<div id="kelas" class="masthead bg-primary text-center text-light mb-0"> 
<h2>Edit Kelas</h2>
<center>
<div class="divider-custom divider-light">
    <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
    <div class="divider-custom-line"></div>
</div>
<form action="{{ url('kelas/' . $kelas->id.'/update') }}" method="post" class="lead">
{{csrf_field()}}
<div class="form-group">

<label for="id_kelas" class="control-label text-secondary">ID Kelas    :   </label>

<input name="id_kelas" type="text" class="form-control col-sm-4 col-form-label text-md-center"value="{{$kelas->id_kelas}}">

</div>
<div class="form-group">

<label for="nama_kelas" class="control-label text-secondary">Nama Kelas  :   </label>

<input name="nama_kelas" type="text" class="form-control col-md-4 col-form-label text-md-center" value="{{$kelas->nama_kelas}}">

</div>
<br>
<button type="submit" class="btn btn-outline-light btn-xl">Submit</button>
<a href="kelas" class="btn btn-outline-light btn-xl">Cancel</a>
</form>

</center>
</div>
@stop