@extends('template')

@section('main')
  <div id="kelas" class="masthead bg-primary">
    <h2>Detail Kelas</h2>

    <table class="lead table table-striped">
    <tbody>
      <tr>
        <th>ID Kelas</th>
        <td>{{ $kelas->id_kelas }}</td>
      </tr>
      <tr>
        <th>Nama Kelas</th>
        <td>{{ $kelas->nama_kelas }}</td>
      </tr>
      <tr>
        <th>Anggota Siswa</th>
        <td>
        @foreach( $kelas->siswa as $list )
        
          <p>> {{ !empty($list->nama_siswa) ?
                        $list->nama_siswa : '-' }}<br>
                        
        @endforeach
        </td>
        </tr>
        </tbody>
        <tr>
    </table>
    <center>
    <a href="http://localhost/laravel/public/kelas" class=" btn btn-outline-light btn-xl"><- Go Back</a>
    </center>
  </div>
@stop