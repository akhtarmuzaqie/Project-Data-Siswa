@extends('template')

@section('main')
<section class="masthead text-light bg-primary text-center" id="kelas">
    
        <h2>Daftar Kelas</h2>
        <div class="divider-custom divider-light">
        <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
        <div class="divider-custom-line"></div>
      </div>    
        @if (!empty($kelas_list))
        
          <table class="table lead text-center text-secondary ">
          <thead>
            <tr>
              <th>ID Kelas</th>
              <th>Nama Kelas</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>

          <?php  $i=0 ?>
            @foreach($kelas_list as $kelas)
              
              <tr>
              
                <td>{{ $kelas->id_kelas }}</td>
                <td>{{ $kelas->nama_kelas }}</td>
                <td><a class="btn btn-success btn-sm" href="{{ url('kelas/' . $kelas->id) }}">Detail</a>
                <a class="btn btn-warning btn-sm" href="{{ url('kelas/' . $kelas->id.'/edit') }}">Edit</a>
                <a class="btn btn-danger btn-sm" href="{{ url('kelas/' . $kelas->id.'/delete') }}" onclick="confirm('Are you sure you want to delete this?')">Delete</a></td>
                <?php $i++ ?>
              </tr>
            
            @endforeach
          </tbody>
          <tr>
          </table>
          <h4 class="text-center text-secondary"><?php echo "Jumlah Total Kelas: $i"; ?></h4>
        @else   
            <p>Tidak ada data kelas</p>
        @endif
        
        <br>
        <a href="{{ url('kelas/create') }}" class="btn btn-outline-light btn-xl"> + Tambah Kelas</a>
    
</section>
  
@stop 


