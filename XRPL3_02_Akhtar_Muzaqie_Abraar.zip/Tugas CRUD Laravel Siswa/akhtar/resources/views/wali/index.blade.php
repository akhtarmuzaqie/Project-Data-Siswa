@extends('template')

@section('main')
<section class="masthead text-light bg-primary text-center" id="wali">
    
        <h2>Daftar Wali Kelas</h2>
        <div class="divider-custom divider-light">
        <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
        <div class="divider-custom-line"></div>
      </div>    
        @if (!empty($wali_list))
        
          <table class="table lead text-center text-secondary ">
          <thead>
            <tr>
              <th>Nama Guru</th>
              <th>Nama Kelas</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>

            @foreach($wali_list as $wali)
              
              <tr>
              
              <td>{{ !empty($wali->guru->nama_guru) ?
                $wali->guru->nama_guru : '-'}}
              
              </td>
                <td>{{ !empty($wali->kelas->nama_kelas) ?
                          $wali->kelas->nama_kelas : '-'}}</td>
                <td>
                <a class="btn btn-warning btn-sm" href="{{ url('wali/' . $wali->id.'/edit') }}">Edit</a>
                <a href="{{ url('wali/' . $wali->id.'/delete') }}" onclick="return confirm('Are you sure you want to delete this?')">
                <button type="button" class="btn btn-danger btn-sm">
                Delete
                </button>
                </a></td>

              </tr>
            
            @endforeach
          </tbody>
          <tr>
          </table>
        @else   
            <p>Tidak ada data Wali Kelas</p>
        @endif
        
        <br>
        <a href="{{ url('wali/create') }}" class="btn btn-outline-light btn-xl"> + Tambah Wali Kelas</a>
    
</section>
  
@stop 

