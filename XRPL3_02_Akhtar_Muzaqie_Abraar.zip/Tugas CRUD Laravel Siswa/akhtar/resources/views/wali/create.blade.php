@extends('template')
@section('main')
<div id="wali" class="masthead bg-primary text-center text-light mb-0"> 
<h2>Tambah Siswa</h2>
<center>
<div class="divider-custom divider-light">
    <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
    <div class="divider-custom-line"></div>
</div>
<form action="{{ url('wali') }}" method="post" class="lead" enctype="multipart/form-data">
{{csrf_field()}}
<div class="form-group">

<label for="id_kelas" class="control-label text-secondary">Nama Kelas :</label>


<select class="form-control col-md-4 col-form-label text-center" type="text"  name="id_kelas">
            @foreach ($kelas as $kelas)
            <option value="{{$kelas->id_kelas}}">>{{$kelas->nama_kelas}}</option>
            @endforeach
</select>


</div>

<div class="form-group">

<label for="nip" class="control-label text-secondary">Nama Guru :</label>

<select class="form-control col-md-4 col-form-label text-center" type="text"  name="nip">
            @foreach ($guru as $guru)
            <option value="{{$guru->nip}}">>{{$guru->nama_guru}}</option>
            @endforeach
</select>



</div>
<br>
<button type="submit" class="btn btn-outline-light btn-lg">Submit</button>
<a href="{{'wali'}}" class="btn btn-outline-light btn-lg">Cancel</a>
</form>

</center>
</div>
@stop