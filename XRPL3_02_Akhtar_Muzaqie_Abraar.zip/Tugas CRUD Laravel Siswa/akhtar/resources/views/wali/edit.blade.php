@extends('template')

@section('main')
<div id="wali" class="masthead bg-primary text-center text-light mb-0"> 
<h2>Edit Walikelas</h2>
<center>
<div class="divider-custom divider-light">
    <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
    <div class="divider-custom-line"></div>
</div>
<form action="{{ url('wali/' . $wali->id.'/update') }}" method="post" class="lead" enctype="multipart/form-data">
	{{csrf_field()}}

	<div class="form-group">
		<label for="id_kelas" class="control-label text-secondary">Nama Kelas   :</label>
		<select required class="form-control col-form-label text-center" type="text" name="id_kelas">
			@foreach ($kelas as $k)
			<option value="{{$k->id_kelas}}">>{{$k->nama_kelas}}</option>
			@endforeach
		</select>
	</div>
	<div class="form-group">
		<label for="nip" class="control-label text-secondary">Nama Guru   :</label>
		<select required class="form-control col-form-label text-center" type="text" name="nip">
			@foreach ($guru as $g)
			<option value="{{$g->nip}}">>{{$g->nama_guru}}</option>
			@endforeach
		</select>
	</div>
	<br>
	<button type="submit" class="btn btn-outline-light btn-x1">->Submit</button>
	<a href="wali" class="btn btn-outline-light btn-x1">cancel</a>
</form>
</div>
@stop