<section class="copyright py-3 text-center text-white fixed" style="position:fixed; width:100%; bottom:0px;" >
    <div class="container">
        <footer>Copyright &copy;VORTEX Spiral</footer>
    </div>
</section>
