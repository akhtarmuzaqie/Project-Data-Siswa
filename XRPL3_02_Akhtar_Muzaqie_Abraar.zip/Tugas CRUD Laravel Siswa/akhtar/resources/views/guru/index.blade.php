@extends('template')

@section('main')
<section class="masthead text-light bg-primary text-center" id="guru">
    
        <h2>Daftar Guru</h2>
        <div class="divider-custom divider-light">
        <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
        <div class="divider-custom-line"></div>
      </div>    
    @if (!empty($guru_list))
    <table class="table lead text-center text-secondary ">
        <thead>
            <tr>
                <th>NIP</th>
                <th>Nama </th>
                <th>Tgl Lahir</th>
                <th>Jenis Kelamin</th>
                <th>aksi</th>
            </tr>
        </thead>
        <tbod
        >
            @foreach($guru_list as $guru)
            <tr>
                <td>{{ $guru->nip }}</td>
                <td>{{ $guru->nama_guru }}</td>
                <td>{{ $guru->tanggal_lahir }}</td>
                <td>{{ $guru->jenis_kelamin }}</td>
                <td>
            <a class="btn btn-success btn-sm" href="{{ url('guru/' .$guru->id)}}">Detail</a>
            <a href="{{ url('guru/'.$guru->id.'/edit')}}" class="btn btn-warning btn-sm">Edit</a>
            <a href="{{ url('guru/'.$guru->id.'/delete')}}" class="btn btn-danger btn-sm">Delete</a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    
    @else
    <p>Data guru tidak muncul</p>
    @endif

    <a href="{{ url('guru/create')}}" class="btn btn-outline-light btn-xl">+ Tambah Pengajar</a>
    <br>
    <br>
    <br>
</div>
@stop


@section('footer')

@stop


