@extends('template')
@section('main')
<div id="guru" class="masthead bg-primary text-center text-light mb-0"> 
<h2>Edit Guru</h2>
<center>
<div class="divider-custom divider-light">
    <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
    <div class="divider-custom-line"></div>
</div>
<form action="{{ url('guru/' . $guru->id . '/update') }}" method="post" class="lead">
{{ csrf_field() }}
<div class="form-group">

<label for="nip" class="control-label text-secondary">NIP    :   </label>

<input name="nip" type="text" class="form-control col-sm-4 col-form-label text-md-center"value="{{$guru->nip}}">

</div>
<div class="form-group">

<label for="nama_guru" class="control-label text-secondary">Nama  :   </label>

<input name="nama_guru" type="text" class="form-control col-md-4 col-form-label text-md-center" value="{{$guru->nama_guru}}">

</div>
<div class="form-group">

<label for="tanggal_lahir" class="control-label text-secondary">Tanggal Lahir  : </label>

<input name="tanggal_lahir" type="date"class="form-control col-md-4 col-form-label text-md-center" value="{{$guru->tanggal_lahir}}">

<div class="form-group">

<label for="jenis_kelamin" class="control-label text-secondary ">Jenis Kelamin :</label>
<br>
@if ($guru->jenis_kelamin=="P")

<select class="form-control col-md-4 col-form-label text-md-center" type="text" name="jenis_kelamin" >
    <option value="P">Perempuan</option>
    <option value="L">Laki-Laki</option>
    

    
</select>




@elseif ($guru->jenis_kelamin=="L")

<select class="form-control col-md-4 col-form-label text-md-center" type="text" name="jenis_kelamin">
    <option value="L">Laki-Laki</option>
    <option value="P">Perempuan</option>

    
</select>
</label>


@endif
</div>
<br>
<button type="submit" class="btn btn-outline-light btn-xl">Submit</button>
<a href="http://localhost/laravel/public/guru" class="btn btn-outline-light btn-xl">Cancel</a>
</form>

</center>
</div>
@stop