@extends('template')

@section('main')
 <div id="siswa" class="masthead bg-primary">
    <h2 class="text-center">Detail Guru</h2>

    <tr>
    	<center>
    		<div class="profile-main">
    			<img src="{{asset('img/'.$guru->image)}}" class="rounded-circle" alt="image" style="width: 10%;">
    			<h3 class="name">{{$guru->nama_guru}}</h3>

    		</div>
    	</center>
    </tr>

    <table class="lead table table-striped">
      <tbody>
      <tr>
        <th>NIP</th>
        <td>{{ $guru->nip }}</td>
      </tr>
      <tr>
        <th>Nama</th>
        <td>{{ $guru->nama_guru }}</td>
      </tr>
      <tr>
        <th>Tanggal Lahir</th>
        <td>{{ $guru->tanggal_lahir }}</td>
      </tr>
      <tr>
        <th>Jenis Kelamin</th>
        <td>{{ $guru->jenis_kelamin }}</td>
      </tr>
      </tbody>
      <tr>
      </tbody>
      <tr>
    </table>
    <center>
    <a href="{{ url('guru')}}" class=" btn btn-outline-light btn-xl"><- Go Back</a>
    </center>
  </div>
@stop