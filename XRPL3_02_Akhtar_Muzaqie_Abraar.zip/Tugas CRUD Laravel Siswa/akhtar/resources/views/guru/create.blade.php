@extends('template')
@section('main')
<div id="siswa" class="masthead bg-primary text-center text-light mb-0"> 
<h2>Tambah Guru</h2>
<center>
<div class="divider-custom divider-light">
    <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
    <div class="divider-custom-line"></div>
</div>
<form action="{{ url('guru') }}" method="post" class="lead" enctype="multipart/form-data">
{{ csrf_field()}}
<div class="form-group">

<label for="nip" class="control-label text-secondary">NIP    : </label>  <input name="nip" type="text" class="form-control col-md-4 col-form-label text-md-center">



</div>




<div class="form-group">

<label for="nama_guru" class="control-label text-secondary">Nama Guru :   </label><input name="nama_guru" type="text" class="form-control col-md-4 col-form-label text-md-center">



</div>
<div class="form-group">

<label for="tanggal_lahir" class="control-label text-secondary">Tanggal Lahir  :</label> <input name="tanggal_lahir" type="date"class="form-control col-md-4 col-form-label text-md-center">


</div>
<div class="form-group">

<label for="jenis_kelamin" class="control-label text-secondary">Jenis Kelamin :</label>


<select class="form-control col-md-4 col-form-label text-md-center" type="text" name="jenis_kelamin">
    <option value=""> </option>
    <option value="L">Laki-Laki</option>
    <option value="P">Perempuan</option>

    
</select>



</div>
<div class="form-group">

<label for="image" class="control-label text-secondary">pilih Gambar  :</label> 
<input name="image" type="file" class="form-control col-md-4 col-form-label text-md-center">
  

</div>
<br>
<button type="submit" class="btn btn-outline-light btn-lg">Submit</button>
<a href="{{url('guru')}}" class="btn btn-outline-light btn-lg">Cancel</a>
</form>

</center>
</div>
@stop