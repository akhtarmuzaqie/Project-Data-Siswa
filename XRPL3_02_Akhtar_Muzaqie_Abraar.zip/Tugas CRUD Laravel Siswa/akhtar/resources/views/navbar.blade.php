<!-- Navigation -->
  <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="http://localhost/laravel/public/">Laravel</a>
      <button class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
        @guest
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                            </li>
                            @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                                </li>
                            @endif
                        @else
                            
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="home">Home</a>
          </li>
          <li class="nav-item mx-0 mx-lg-1 dropdown">
            <a id="navbarDropdown" class="py-3 px-0 px-lg-3 nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
              LIST <span class="caret"></span>
            </a>
            <div class=" dropdown-menu mx-0 mx-lg dropdown-menu-right" aria-labelledby="navbarDropdown">
              <a class="mx-0 mx-md dropdown-item" href="siswa">Siswa</a>
              <a class="mx-0 mx-md dropdown-item" href="guru">Guru</a>
              <a class="mx-0 mx-md dropdown-item" href="kelas">Kelas</a>
              <a class="mx-0 mx-md dropdown-item" href="wali">Walikelas</a>
          </li>
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="about">About</a>
          </li>
          <li class="nav-item mx-0 mx-lg-1 dropdown">
           <a id="navbarDropdown" class="py-3 px-0 px-lg-3 nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
              {{ Auth::user()->name }} <span class="caret"></span>
            </a>

             <div class=" dropdown-menu mx-0 mx-lg dropdown-menu-right" aria-labelledby="navbarDropdown">
              <a class="mx-0 mx-md dropdown-item" href="{{ route('logout') }}"
                    onclick="event.preventDefault();
                             document.getElementById('logout-form').submit();">
                        {{ __('Logout') }}
               </a>

              <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                  {{ csrf_field()}}
              </form>
            </div>
          </li>
          @endguest
        </ul>
      </div>
    </div>
  </nav>